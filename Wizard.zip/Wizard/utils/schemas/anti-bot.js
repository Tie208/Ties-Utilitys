module.exports = () => {
    _id: {
        func: Boolean
        settings: {
            user_punish: String
            bot_punish: String
        }
}
    
}

// All of these have a base like this where you can understand how the data is being stored!!